-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: mariaDB
-- Generation Time: Sep 22, 2022 at 12:27 PM
-- Server version: 8.0.29
-- PHP Version: 8.0.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `be_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2022_09_20_142558_create_products_table', 1),
(6, '2022_09_20_142714_create_user_redeems_table', 1),
(7, '2022_09_20_152439_create_product_stars_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stock` int NOT NULL,
  `price` decimal(8,2) NOT NULL,
  `star` int NOT NULL DEFAULT '0',
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `stock`, `price`, `star`, `image`, `description`, `deleted_at`, `created_at`, `updated_at`) VALUES
('0aa9580b-b5e3-455d-aac4-58d0534a62b4', 'Cassie Lesch', 88, '4430.00', 0, 'https://via.placeholder.com/640x480.png/009922?text=ullam', 'Reprehenderit omnis id deleniti vero possimus in nisi. Sit sit quia sed consectetur delectus a recusandae. Eaque qui quia et sunt.', NULL, '2022-09-22 00:08:31', '2022-09-22 00:08:31'),
('1d1f0b25-91e8-4438-8a95-2fa368cdd15f', 'Liana Rempel', 89, '2706.00', 0, 'https://via.placeholder.com/640x480.png/007711?text=nisi', 'Laborum hic iste ab et reiciendis cumque. Iusto saepe possimus laboriosam. Numquam ut ut repellat consectetur enim consequatur explicabo.', NULL, '2022-09-22 00:08:31', '2022-09-22 00:08:31'),
('21c7a879-f066-4ac0-a422-bb19ff17c3ad', 'Helen Lindgren', 45, '7424.00', 0, 'https://via.placeholder.com/640x480.png/005511?text=labore', 'Suscipit porro dolorum in voluptatibus qui ipsum sit eum. Facere ut quis magnam nulla. Similique consequatur porro quisquam ab.', NULL, '2022-09-22 00:08:31', '2022-09-22 00:08:31'),
('251d3167-2056-495c-a8d4-53c06749f4ac', 'test update', 30, '20000.00', 0, NULL, NULL, '2022-09-22 01:51:26', '2022-09-22 01:50:16', '2022-09-22 01:51:26'),
('29b67d96-f42e-4395-803e-1c141b3a3785', 'Dr. Arne Smitham II', 8, '3913.00', 0, 'https://via.placeholder.com/640x480.png/009922?text=ut', 'Id quia est dolorem earum nostrum. Aliquam aliquam et autem.', NULL, '2022-09-22 00:08:31', '2022-09-22 00:08:31'),
('37b4e9ef-f728-4bd1-b807-a0a0e8b53948', 'Jeramy Altenwerth', 38, '6025.00', 0, 'https://via.placeholder.com/640x480.png/00bb88?text=nulla', 'Officia cumque vel quas placeat expedita. Maiores porro illum quibusdam voluptatem et et maxime. Illo facilis enim possimus voluptatem.', NULL, '2022-09-22 00:08:31', '2022-09-22 00:08:31'),
('55132fdd-3950-463d-b80b-4d3857515439', 'Jena Pfeffer', 18, '5967.00', 0, 'https://via.placeholder.com/640x480.png/0011cc?text=nisi', 'Est est ipsum quibusdam sit tempora aut laudantium dolores. Nisi est et illo officiis ea ad non. Quisquam animi voluptas sed dolores.', NULL, '2022-09-22 00:08:31', '2022-09-22 00:08:31'),
('682debbb-a643-4b56-b5db-6ab5840ac1b5', 'Rasheed Johnston', 57, '4145.00', 0, 'https://via.placeholder.com/640x480.png/0077cc?text=occaecati', 'Quas sint molestiae ipsam ducimus eum illum corporis. Consequatur quas exercitationem dolore vero. Nihil saepe sunt provident eos ut accusantium soluta.', NULL, '2022-09-22 00:08:31', '2022-09-22 00:08:31'),
('6b3c2967-2698-4386-8034-7c52ec55389b', 'Miss Marlene Trantow DVM', 67, '269.00', 0, 'https://via.placeholder.com/640x480.png/00ee00?text=quia', 'Velit qui voluptatem veniam perferendis occaecati et. Provident sed soluta culpa voluptatem libero non. Delectus non aspernatur inventore a. Sit sit quo eos molestias.', NULL, '2022-09-22 00:08:31', '2022-09-22 00:08:31'),
('6d2236bc-92ac-4b27-a901-81ebe444f3ac', 'Prof. Walton Ondricka', 55, '7877.00', 0, 'https://via.placeholder.com/640x480.png/00aa66?text=odit', 'Non repellendus cupiditate qui veniam odit sed. Vero et est quia iste occaecati recusandae. Placeat sunt corrupti voluptatem alias quia.', NULL, '2022-09-22 00:08:31', '2022-09-22 12:22:54'),
('7bae0feb-279b-44da-baf2-4866eeb1f6b3', 'Allene Schmeler Jr.', 51, '7960.00', 0, 'https://via.placeholder.com/640x480.png/006699?text=soluta', 'Adipisci magnam labore veniam sed excepturi itaque vel vero. Expedita tenetur esse quia possimus ea. Nostrum id dolorem sapiente nesciunt voluptas labore molestias provident.', '2022-09-22 00:54:57', '2022-09-22 00:08:31', '2022-09-22 00:54:57'),
('98b04f97-95fe-46c1-b157-3d19b48ddeeb', 'Murphy Medhurst IV', 72, '2011.00', 0, 'https://via.placeholder.com/640x480.png/0088aa?text=nemo', 'Impedit excepturi dolores ullam sed. Iste placeat aliquam quo in aliquam eius. Repellat et earum aspernatur. Dignissimos non tenetur recusandae soluta deserunt sit voluptates ut.', NULL, '2022-09-22 00:08:31', '2022-09-22 00:08:31'),
('a2140455-bf71-4820-a157-7d26d8ca67f6', 'Jules Abbott', 86, '7417.00', 0, 'https://via.placeholder.com/640x480.png/009988?text=dolore', 'Dolore cupiditate qui facere tenetur nobis. Atque cum error odit architecto voluptate soluta et in. Delectus animi ratione eaque vitae accusantium dolorum.', NULL, '2022-09-22 00:08:31', '2022-09-22 00:08:31'),
('bac7a580-516b-415e-97d3-1e4e3bfa6ffc', 'Bradford Hickle', 16, '6296.00', 0, 'https://via.placeholder.com/640x480.png/007766?text=debitis', 'Odit eum sed perspiciatis et harum minima non nemo. Voluptatem aspernatur id nostrum consequatur tempora esse mollitia corrupti.', NULL, '2022-09-22 00:08:31', '2022-09-22 00:08:31'),
('bfb43923-d2ec-4ade-97f5-edc73bba9dc4', 'Leif Satterfield', 36, '1549.00', 0, 'https://via.placeholder.com/640x480.png/002277?text=dignissimos', 'Natus molestias soluta voluptatum temporibus adipisci voluptas nesciunt. Quia quis rerum aut voluptas. Atque delectus et distinctio et explicabo tempore recusandae. Laborum dicta illum qui soluta.', NULL, '2022-09-22 00:08:31', '2022-09-22 00:08:31'),
('d53dc2c4-5a67-48cc-a68f-374e2a60ec2b', 'Maia Rodriguez', 52, '1694.00', 0, 'https://via.placeholder.com/640x480.png/001122?text=possimus', 'Quas nulla earum voluptate qui aliquid. Perferendis delectus omnis tenetur sit quae rerum.', NULL, '2022-09-22 00:08:31', '2022-09-22 00:08:31'),
('e21f2863-7811-4e88-ad70-6b47b8549073', 'Nolan Wolff', 17, '8511.00', 0, 'https://via.placeholder.com/640x480.png/006644?text=nisi', 'Quis ducimus dolores sunt sit quis. Aut accusantium debitis error excepturi perferendis sunt et. Tenetur quisquam ex voluptatibus aliquam neque.', NULL, '2022-09-22 00:08:31', '2022-09-22 00:08:31'),
('efea95c8-2277-490d-a980-8e8f02bb5c10', 'Benton Harris', 65, '2520.00', 5, 'https://via.placeholder.com/640x480.png/003366?text=non', 'Ipsam et et quae et nihil minima dignissimos. Non minus eum laboriosam sed enim tempore. Et recusandae eos magni.', NULL, '2022-09-22 00:08:31', '2022-09-22 12:23:26'),
('fe99bfda-822e-4b3d-9db9-e246a5371513', 'Dr. Anastasia Runolfsdottir', 48, '3877.00', 3, 'https://via.placeholder.com/640x480.png/00cc99?text=voluptates', 'Maiores non corrupti ut et quibusdam. Optio ipsum totam vero doloremque ut. Nulla necessitatibus nam beatae repellendus odit. Est error aliquid aut unde qui accusantium.', NULL, '2022-09-22 00:08:31', '2022-09-22 12:12:40');

-- --------------------------------------------------------

--
-- Table structure for table `product_stars`
--

CREATE TABLE `product_stars` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `star` int NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_stars`
--

INSERT INTO `product_stars` (`id`, `user_id`, `product_id`, `star`, `deleted_at`, `created_at`, `updated_at`) VALUES
('02186adc-e242-4a0f-9af2-c2720e28e2c0', 'bca87798-3fc8-4ce0-8b44-937c615e1637', 'fe99bfda-822e-4b3d-9db9-e246a5371513', 1, NULL, '2022-09-22 00:14:35', '2022-09-22 00:14:35'),
('3540dec9-5135-40ed-adad-086dc7f3cf58', '2960f818-1011-4701-8bf4-e3d6b130a1ec', 'efea95c8-2277-490d-a980-8e8f02bb5c10', 5, NULL, '2022-09-22 12:23:11', '2022-09-22 12:23:11'),
('828c1a85-97d6-4fdd-ace0-0d84d237d891', '2960f818-1011-4701-8bf4-e3d6b130a1ec', 'fe99bfda-822e-4b3d-9db9-e246a5371513', 5, NULL, '2022-09-22 00:31:17', '2022-09-22 00:32:14');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `deleted_at`, `created_at`, `updated_at`) VALUES
('2960f818-1011-4701-8bf4-e3d6b130a1ec', 'test', 'test1@gmail.com', NULL, '$2y$10$icF2EivmE33btSA4zRxLHufg7Muyq4yEVBQGcHFF27KENdjkBY.Ea', NULL, NULL, '2022-09-22 00:31:00', '2022-09-22 00:31:00'),
('342841fc-7411-45a0-8f7c-eaa2fd22189a', 'Lance Reichel Jr.', 'audra.spinka@example.com', '2022-09-22 00:08:31', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'bXKPs4qrzo', NULL, '2022-09-22 00:08:31', '2022-09-22 00:08:31'),
('3e5ec3fd-839d-4ab0-9b96-f4a03ab78374', 'Mr. Deshaun Romaguera', 'noel.prosacco@example.org', '2022-09-22 00:08:31', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'DLmhXKRNtb', NULL, '2022-09-22 00:08:31', '2022-09-22 00:08:31'),
('850e2915-36ff-4357-9752-68d0808459e3', 'Dr. Brennon Orn', 'gleason.thomas@example.com', '2022-09-22 00:08:31', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'SZ4Lu5ZySd', NULL, '2022-09-22 00:08:31', '2022-09-22 00:08:31'),
('965e1511-adf1-4061-ab28-b69cbd75dae3', 'test', 'test2@gmail.com', NULL, '$2y$10$4v03QmgyKxWJp4WsRP0P0.LPJGQTiUayA2rSqk8miqq1RyF.wfQi.', NULL, NULL, '2022-09-22 01:49:47', '2022-09-22 01:49:47'),
('bca87798-3fc8-4ce0-8b44-937c615e1637', 'Test User', 'user@gmail.com', '2022-09-22 00:08:31', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '6xH1ISDp5f', NULL, '2022-09-22 00:08:31', '2022-09-22 00:08:31'),
('cc54bcbe-a08e-4e0f-baef-625fbd194f1d', 'Mr. Frankie Walter', 'funk.luella@example.org', '2022-09-22 00:08:31', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'SzfsCJg9IG', NULL, '2022-09-22 00:08:31', '2022-09-22 00:08:31'),
('d5caaac0-500f-43e4-8606-0dfb140d2ab9', 'Cathrine Thompson', 'weimann.madge@example.net', '2022-09-22 00:08:31', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Xez8gqLaYJ', NULL, '2022-09-22 00:08:31', '2022-09-22 00:08:31');

-- --------------------------------------------------------

--
-- Table structure for table `user_redeems`
--

CREATE TABLE `user_redeems` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_redeems`
--

INSERT INTO `user_redeems` (`id`, `user_id`, `product_id`, `deleted_at`, `created_at`, `updated_at`) VALUES
('253feb16-e2f2-4afe-a51b-51d9ac18aac1', '2960f818-1011-4701-8bf4-e3d6b130a1ec', 'fe99bfda-822e-4b3d-9db9-e246a5371513', NULL, '2022-09-22 00:53:22', '2022-09-22 00:53:22'),
('2bf2852e-7966-41df-8515-2cd805133bc1', '2960f818-1011-4701-8bf4-e3d6b130a1ec', 'fe99bfda-822e-4b3d-9db9-e246a5371513', NULL, '2022-09-22 00:53:29', '2022-09-22 00:53:29'),
('3f9f1255-82e8-4d2d-af7b-fa0e95e284f1', '2960f818-1011-4701-8bf4-e3d6b130a1ec', '6d2236bc-92ac-4b27-a901-81ebe444f3ac', NULL, '2022-09-22 12:22:54', '2022-09-22 12:22:54'),
('592b3279-241c-4e25-b4a9-7dd0d6256d35', '2960f818-1011-4701-8bf4-e3d6b130a1ec', 'efea95c8-2277-490d-a980-8e8f02bb5c10', NULL, '2022-09-22 12:23:26', '2022-09-22 12:23:26'),
('88ad2c49-96e5-4b5e-b201-4ff8e58062a8', '2960f818-1011-4701-8bf4-e3d6b130a1ec', 'fe99bfda-822e-4b3d-9db9-e246a5371513', NULL, '2022-09-22 12:12:41', '2022-09-22 12:12:41'),
('a453e734-0d6a-439d-b6eb-a2bfeb8a490c', '2960f818-1011-4701-8bf4-e3d6b130a1ec', 'efea95c8-2277-490d-a980-8e8f02bb5c10', NULL, '2022-09-22 12:22:54', '2022-09-22 12:22:54'),
('c99a0c95-03f5-4f32-8b49-945db265976e', '2960f818-1011-4701-8bf4-e3d6b130a1ec', 'fe99bfda-822e-4b3d-9db9-e246a5371513', NULL, '2022-09-22 01:51:33', '2022-09-22 01:51:33');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_stars`
--
ALTER TABLE `product_stars`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_stars_user_id_foreign` (`user_id`),
  ADD KEY `product_stars_product_id_foreign` (`product_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `user_redeems`
--
ALTER TABLE `user_redeems`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_redeems_product_id_foreign` (`product_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `product_stars`
--
ALTER TABLE `product_stars`
  ADD CONSTRAINT `product_stars_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  ADD CONSTRAINT `product_stars_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

--
-- Constraints for table `user_redeems`
--
ALTER TABLE `user_redeems`
  ADD CONSTRAINT `user_redeems_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
